import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(CalculatorApp());

class CalculatorApp extends StatelessWidget {
  const CalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Calculator',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: CalculatorScreen(),
    );
  }
}

class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});

  @override
  _CalculatorScreenState createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  String display = "0";
  double result = 0;
  String lastOperation = '';
  String currentInput = '';
  String previousInput = '';

  @override
  void initState() {
    super.initState();
    _loadLastState();
  }

  _loadLastState() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      result = prefs.getDouble('lastResult') ?? 0;
      display = result.toString();
    });
  }

  _saveState() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setDouble('lastResult', result);
  }

  void _buttonPressed(String buttonText) {
    setState(() {
      if (buttonText == 'C') {
        display = '0';
        currentInput = '';
        previousInput = '';
        result = 0;
      } else if (buttonText == 'CE') {
        display = '0';
        currentInput = '';
      } else if (buttonText == '=') {
        if (currentInput.isNotEmpty) {
          _calculateResult();
        }
      } else if (buttonText == '+' || buttonText == '-' || buttonText == '*' || buttonText == '/') {
        if (currentInput.isNotEmpty) {
          previousInput = currentInput;
          currentInput = '';
          lastOperation = buttonText;
        }
      } else {
        if (currentInput == '0') {
          currentInput = buttonText;
        } else {
          currentInput += buttonText;
        }
      }
      display = currentInput.isEmpty ? '0' : currentInput;
    });
  }

  void _calculateResult() {
    if (previousInput.isEmpty) return;
    double prev = double.tryParse(previousInput) ?? 0;
    double curr = double.tryParse(currentInput) ?? 0;

    switch (lastOperation) {
      case '+':
        result = prev + curr;
        break;
      case '-':
        result = prev - curr;
        break;
      case '*':
        result = prev * curr;
        break;
      case '/':
        if (curr == 0) {
          result = double.nan;
        } else {
          result = prev / curr;
        }
        break;
    }

    setState(() {
      display = result.toString();
      currentInput = '';
      previousInput = '';
      lastOperation = '';
    });

    _saveState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Calculator')),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Text(
              display,
              style: TextStyle(fontSize: 48, fontWeight: FontWeight.bold),
            ),
          ),
          GridView.builder(
            shrinkWrap: true,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
            ),
            itemCount: 16,
            itemBuilder: (context, index) {
              String buttonText = '';
              if (index < 9) {
                buttonText = (index + 1).toString();
              } else if (index == 9) {
                buttonText = 'CE';
              } else if (index == 10) {
                buttonText = '0';
              } else if (index == 11) {
                buttonText = 'C';
              } else if (index == 12) {
                buttonText = '+';
              } else if (index == 13) {
                buttonText = '-';
              } else if (index == 14) {
                buttonText = '*';
              } else if (index == 15) {
                buttonText = '/';
              }

              return ElevatedButton(
                onPressed: () => _buttonPressed(buttonText),
                child: Text(buttonText, style: TextStyle(fontSize: 24)),
              );
            },
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: ElevatedButton(
              onPressed: () => _buttonPressed('='),
              child: Text('=', style: TextStyle(fontSize: 24)),
            ),
          ),
        ],
      ),
    );
  }
}

extension on SharedPreferences {
  void setDouble(String s, double result) {}
}

class SharedPreferences {
  getDouble(String s) {}
  
  static getInstance() {}
}
